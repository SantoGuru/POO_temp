package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import domain.Quarto;

public class QuartoDAO implements GenericDAO<Quarto> {
	public String ClassName = "Quarto";
	public String filePath = "./Files/";
	public String fileType = ".txt";
	public DataBase DB = new DataBase(new File(filePath + ClassName + fileType));

	@Override
	public Quarto consultar(Quarto quarto) throws IOException {
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			String[] dados = linha.split(",");
			if (dados.length > 0 && Integer.parseInt(dados[0]) == quarto.getCodigo()) {
				Quarto encontrado = new Quarto();
				encontrado.toObject(linha);
				BR.close();
				return encontrado;
			}
		}
		BR.close();
		return null;
	};

	@Override
	public Quarto cadastrar(Quarto quarto) throws IOException {
		Quarto consultaExist = this.consultar(quarto);
		if (consultaExist == null) {
			File file = DB.load(ClassName);
			FileReader FR = new FileReader(file);
			BufferedReader BR = new BufferedReader(FR);
			FileWriter FW = new FileWriter(file, true);
			BufferedWriter BW = new BufferedWriter(FW);
			if (BR.readLine() == null) {
				BW.write(quarto.toString());
			} else {
				BW.newLine();
				BW.write(quarto.toString());
			}
			BR.close();
			BW.close();
			System.out.println("Quarto cadastrado!");
			return quarto;
		} else {
			System.out.println("ERRO: Quarto já cadastrado!");
			return null;
		}
	}

	public ArrayList<Quarto> listar(Quarto quarto) throws IOException {
		ArrayList<Quarto> arrayList = new ArrayList<Quarto>();
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			Quarto Listado = new Quarto();
			Listado.toObject(linha);
			arrayList.add(Listado);
		}
		BR.close();
		return arrayList;
	}

	public boolean editar(Quarto quarto) throws IOException {
		Quarto consultaExist = this.consultar(quarto);
		if (consultaExist != null) {
			ArrayList<Quarto> arrayList = this.listar(null);
			for (int i = 0; i < arrayList.size(); i++) {
				if (arrayList.get(i).getCodigo() == (quarto.getCodigo())) {
					arrayList.remove(i);
					arrayList.add(quarto);
					File arquivo = DB.load(ClassName);
					arquivo.delete();
				}
			}
			FileWriter FW = new FileWriter(filePath + ClassName + fileType, true);
			BufferedWriter BW = new BufferedWriter(FW);
			for (Quarto h : arrayList) {
				BW.write(h.toString());
				BW.newLine();
			}
			BW.close();
			return true;
		}
		return false;
	}

}
