package dao;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class DataBase {
	public String filePath = "./Files/";
	public String fileType = ".txt";
	public ArrayList<File> DBfiles = new ArrayList<File>();

	// Metodos

	public File load(String nome) {
		String nomeDB = nome + ".txt";
		for (int i = 0; i < DBfiles.size(); i++) {
			if (DBfiles.get(i).getName().equals(nomeDB)) {
				return DBfiles.get(i);
			}
		}
		return null;
	}

	public Boolean create(File n) {
		if (n.exists()) {
			DBfiles.add(n);
			System.out.println("Carregado: " + n.getName());
			return false;
		} else {
			try {
				FileWriter FW = new FileWriter(filePath + n.getName(), true);
				FW.close();
				DBfiles.add(n);
				System.out.println("Criado: " + n.getName());
				return true;
			} catch (IOException e) {
				System.out.println(e.getCause());
				System.out.println(e.getMessage());
				return null;
			}
		}
	}

	public DataBase(File n) {
		this.create(n);
	}
}
