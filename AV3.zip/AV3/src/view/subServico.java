package view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import dao.ServicoDAO;
import domain.Servico;

public class subServico {
	Scanner scanner = new Scanner(System.in);

	public void subServicoMenu() {
		ServicoDAO servicoDAO = new ServicoDAO();
		System.out.println("===== MENU " + "SERVICO" + " =====");
		System.out.println("1. Consultar");
		System.out.println("2. Editar");
		System.out.println("3. Cadastrar");
		System.out.println("4. Listar");
		System.out.println("0. Voltar");
		System.out.print("Escolha uma opção: ");
		int choice = scanner.nextInt();
		scanner.nextLine(); // Consumir a nova linha

		switch (choice) {
		case 0:
			new Menu();
			break;
		case 1:
			System.out.print("Insira o Código do Servico: ");
			int Codigo1 = scanner.nextInt();
			scanner.nextLine();
			Servico instancia = new Servico();
			instancia.setCodigo(Codigo1);
			try {
				instancia = servicoDAO.consultar(instancia);
				System.out.println(instancia.toString());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subServicoMenu();
			break;
		case 2:
			System.out.print("Insira o Código do Servico: ");
			int editarCodigo = scanner.nextInt();
			scanner.nextLine();
			Servico editarInstancia = new Servico();
			editarInstancia.setCodigo(editarCodigo);

			System.out.print("Digite a descrição: ");
			String descricao = scanner.nextLine();
			editarInstancia.setDescricao(descricao);

			System.out.print("Digite o valor: ");
			double valor = scanner.nextDouble();
			scanner.nextLine();
			editarInstancia.setValor(valor);

			try {
				boolean teste = servicoDAO.editar(editarInstancia);
				if (teste) {
					System.out.println("Editado com sucesso");
				} else {
					System.out.println("Falha ao editar");
				}

			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subServicoMenu();
			break;
		case 3:
			System.out.print("Insira o Código do Servico: ");
			int cadastrarCodigo = scanner.nextInt();
			scanner.nextLine();
			Servico cadastrarInstancia = new Servico();
			cadastrarInstancia.setCodigo(cadastrarCodigo);

			System.out.print("Digite a descrição: ");
			String cadastrarDescricao = scanner.nextLine();
			cadastrarInstancia.setDescricao(cadastrarDescricao);

			System.out.print("Digite o valor: ");
			double cadastrarValor = scanner.nextDouble();
			scanner.nextLine();
			cadastrarInstancia.setValor(cadastrarValor);

			try {
				servicoDAO.cadastrar(cadastrarInstancia);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto já existe no cadastro");
			}
			this.subServicoMenu();
			break;
		case 4:
			Servico a = new Servico();
			try {
				ArrayList<Servico> b = servicoDAO.listar(a);
				for (Servico c : b) {
					System.out.println(c.toString());
				}
				this.subServicoMenu();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subServicoMenu();
			break;
		default:
			System.out.println("Opção inválida. Tente novamente.");
		}

	}

	public subServico() {
		this.subServicoMenu();
	}
}
