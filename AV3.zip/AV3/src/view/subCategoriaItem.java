package view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import dao.CategoriaDAO;
import dao.CategoriaItemDAO;
import dao.ItemDAO;
import domain.Categoria;
import domain.CategoriaItem;
import domain.Item;

public class subCategoriaItem {
	Scanner scanner = new Scanner(System.in);

	public void subCategoriaItemMenu() {
		CategoriaItemDAO categoriaItemDAO = new CategoriaItemDAO();
		System.out.println("===== MENU " + "CategoriaItem" + " =====");
		System.out.println("1. Consultar");
		System.out.println("2. Editar");
		System.out.println("3. Cadastrar");
		System.out.println("4. Listar");
		System.out.println("0. Voltar");
		System.out.print("Escolha uma opção: ");

		int choice = scanner.nextInt();
		scanner.nextLine(); // Consumir a nova linha

		switch (choice) {
		case 0:
			new Menu();
			break;
		case 1:
			CategoriaItem instancia = new CategoriaItem();
			System.out.print("Insira o Código do Item: ");
			Item newItem = new Item();
			ItemDAO sDAO = new ItemDAO();
			int Codigo1 = scanner.nextInt();
			scanner.nextLine();
			newItem.setCodigo(Codigo1);
			try {
				newItem = sDAO.consultar(newItem);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			instancia.setItem(newItem);

			System.out.print("Insira o Código da Categoria: ");
			int Codigo2 = scanner.nextInt();
			scanner.nextLine();
			Categoria newCategoria = new Categoria();
			newCategoria.setCodigo(Codigo2);
			CategoriaDAO qDAO = new CategoriaDAO();
			try {
				newCategoria = qDAO.consultar(newCategoria);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			instancia.setCategoria(newCategoria);

			try {
				instancia = categoriaItemDAO.consultar(instancia);
				System.out.println(instancia.toString());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subCategoriaItemMenu();
			break;
		case 2:
			CategoriaItem instancia1 = new CategoriaItem();
			System.out.print("Insira o Código do Item: ");
			int Codigo11 = scanner.nextInt();
			scanner.nextLine();
			Item newItem1 = new Item();
			newItem1.setCodigo(Codigo11);
			ItemDAO sDAO1 = new ItemDAO();
			try {
				newItem1 = sDAO1.consultar(newItem1);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			instancia1.setItem(newItem1);

			System.out.print("Insira o Código da Categoria: ");
			int Codigo21 = scanner.nextInt();
			scanner.nextLine();
			Categoria newCategoria1 = new Categoria();
			newCategoria1.setCodigo(Codigo21);
			CategoriaDAO qDAO1 = new CategoriaDAO();
			try {
				newCategoria1 = qDAO1.consultar(newCategoria1);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.print("Insira a quantidade: ");
			int Codigo213 = scanner.nextInt();
			scanner.nextLine();
			instancia1.setQuantidade(Codigo213);
			try {
				boolean teste = categoriaItemDAO.editar(instancia1);
				if (teste) {
					System.out.println("Editado com sucesso");
				} else {
					System.out.println("Falha ao editar");
				}

			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subCategoriaItemMenu();
			break;
		case 3:
			CategoriaItem instancia11 = new CategoriaItem();
			System.out.print("Insira o Código do Item: ");
			int Codigo111 = scanner.nextInt();
			scanner.nextLine();
			Item newItem11 = new Item();
			newItem11.setCodigo(Codigo111);
			ItemDAO sDAO11 = new ItemDAO();
			try {
				newItem11 = sDAO11.consultar(newItem11);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			instancia11.setItem(newItem11);

			System.out.print("Insira o Código da Categoria: ");
			int Codigo211 = scanner.nextInt();
			scanner.nextLine();
			Categoria newCategoria11 = new Categoria();
			newCategoria11.setCodigo(Codigo211);
			CategoriaDAO qDAO11 = new CategoriaDAO();
			try {
				newCategoria11 = qDAO11.consultar(newCategoria11);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.print("Insira a quantidade: ");
			int Codigo2131 = scanner.nextInt();
			scanner.nextLine();
			instancia11.setQuantidade(Codigo2131);
			try {
				categoriaItemDAO.cadastrar(instancia11);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto já existe no cadastro");
			}
			this.subCategoriaItemMenu();
			break;
		case 4:
			CategoriaItem a = new CategoriaItem();
			try {
				ArrayList<CategoriaItem> b = categoriaItemDAO.listar(a);
				for (CategoriaItem c : b) {
					System.out.println(c.toString());
				}
				this.subCategoriaItemMenu();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subCategoriaItemMenu();
			break;
		default:
			System.out.println("Opção inválida. Tente novamente.");
		}

	}

	public subCategoriaItem() {
		this.subCategoriaItemMenu();
	}
}
