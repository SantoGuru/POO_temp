package view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import dao.CategoriaDAO;
import dao.QuartoDAO;
import domain.Categoria;
import domain.Quarto;

public class subQuarto {
	Scanner scanner = new Scanner(System.in);

	public void subQuartoMenu() {
		QuartoDAO quartoDAO = new QuartoDAO();
		System.out.println("===== MENU " + "QUARTO" + " =====");
		System.out.println("1. Consultar");
		System.out.println("2. Editar");
		System.out.println("3. Cadastrar");
		System.out.println("4. Listar");
		System.out.println("0. Voltar");
		System.out.print("Escolha uma opção: ");
		int choice = scanner.nextInt();
		scanner.nextLine(); // Consumir a nova linha

		switch (choice) {
		case 0:
			new Menu();
			break;
		case 1:
			System.out.print("Insira o Código do Quarto: ");
			int Codigo1 = scanner.nextInt();
			scanner.nextLine();
			Quarto instancia = new Quarto();
			instancia.setCodigo(Codigo1);
			try {
				instancia = quartoDAO.consultar(instancia);
				System.out.println(instancia.toString());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subQuartoMenu();
			break;
		case 2:
			Quarto newQuarto = new Quarto();
			System.out.print("Insira o ID da Quarto: ");
			int ID = scanner.nextInt();
			newQuarto.setCodigo(ID);
			scanner.nextLine();

			System.out.print("Insira o ID da Categoria: ");
			int ID2 = scanner.nextInt();
			Categoria h = new Categoria();
			h.setCodigo(ID2);
			CategoriaDAO hDAO = new CategoriaDAO();
			try {
				newQuarto.setCategoria(hDAO.consultar(h));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.print("Insira o Status (Y/N): ");
			String ID21 = scanner.nextLine();
			if (ID21.equals("Y")) {
				newQuarto.setStatus("true");
			} else {
				newQuarto.setStatus("false");
			}

			try {
				boolean teste = quartoDAO.editar(newQuarto);
				if (teste) {
					System.out.println("Editado com sucesso");
				} else {
					System.out.println("Falha ao editar");
				}

			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subQuartoMenu();
			break;
		case 3:
			Quarto newQuarto1 = new Quarto();
			System.out.print("Insira o ID da Quarto: ");
			int ID1 = scanner.nextInt();
			newQuarto1.setCodigo(ID1);
			scanner.nextLine();

			System.out.print("Insira o ID da Categoria: ");
			int ID211 = scanner.nextInt();
			Categoria h1 = new Categoria();
			h1.setCodigo(ID211);
			CategoriaDAO hDAO1 = new CategoriaDAO();
			try {
				newQuarto1.setCategoria(hDAO1.consultar(h1));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				quartoDAO.cadastrar(newQuarto1);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto já existe no cadastro");
			}
			this.subQuartoMenu();
			break;
		case 4:
			Quarto a = new Quarto();
			try {
				ArrayList<Quarto> b = quartoDAO.listar(a);
				for (Quarto c : b) {
					System.out.println(c.toString());
				}
				this.subQuartoMenu();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subQuartoMenu();
			break;
		default:
			System.out.println("Opção inválida. Tente novamente.");
		}

	}

	public subQuarto() {
		this.subQuartoMenu();
	}
}
