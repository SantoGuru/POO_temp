package view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import dao.CategoriaDAO;
import domain.Categoria;

public class subCategoria {
	Scanner scanner = new Scanner(System.in);

	public void subCategoriaMenu() {
		CategoriaDAO categoriaDAO = new CategoriaDAO();
		System.out.println("===== MENU " + "CATEGORIA" + " =====");
		System.out.println("1. Consultar");
		System.out.println("2. Editar");
		System.out.println("3. Cadastrar");
		System.out.println("4. Listar");
		System.out.println("0. Voltar");
		System.out.print("Escolha uma opção: ");
		int choice = scanner.nextInt();
		scanner.nextLine(); // Consumir a nova linha

		switch (choice) {
		case 0:
			new Menu();
			break;
		case 1:
			System.out.print("Insira o Código do Categoria: ");
			int Codigo1 = scanner.nextInt();
			scanner.nextLine();
			Categoria instancia = new Categoria();
			instancia.setCodigo(Codigo1);
			try {
				instancia = categoriaDAO.consultar(instancia);
				System.out.println(instancia.toString());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subCategoriaMenu();
			break;
		case 2:
			System.out.print("Insira o Código do Categoria: ");
			int editarCodigo = scanner.nextInt();
			scanner.nextLine();
			Categoria editarInstancia = new Categoria();
			editarInstancia.setCodigo(editarCodigo);

			System.out.print("Digite a descrição: ");
			String descricao = scanner.nextLine();
			editarInstancia.setDescricao(descricao);

			System.out.print("Digite o valor: ");
			double valor = scanner.nextDouble();
			scanner.nextLine();
			editarInstancia.setValor(valor);

			try {
				boolean teste = categoriaDAO.editar(editarInstancia);
				if (teste) {
					System.out.println("Editado com sucesso");
				} else {
					System.out.println("Falha ao editar");
				}

			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subCategoriaMenu();
			break;
		case 3:
			System.out.print("Insira o Código do Categoria: ");
			int cadastrarCodigo = scanner.nextInt();
			scanner.nextLine();
			Categoria cadastrarInstancia = new Categoria();
			cadastrarInstancia.setCodigo(cadastrarCodigo);

			System.out.print("Digite a descrição: ");
			String cadastrarDescricao = scanner.nextLine();
			cadastrarInstancia.setDescricao(cadastrarDescricao);

			System.out.print("Digite o valor: ");
			double cadastrarValor = scanner.nextDouble();
			scanner.nextLine();
			cadastrarInstancia.setValor(cadastrarValor);

			try {
				categoriaDAO.cadastrar(cadastrarInstancia);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto já existe no cadastro");
			}
			this.subCategoriaMenu();
			break;
		case 4:
			Categoria a = new Categoria();
			try {
				ArrayList<Categoria> b = categoriaDAO.listar(a);
				for (Categoria c : b) {
					System.out.println(c.toString());
				}
				this.subCategoriaMenu();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subCategoriaMenu();
			break;
		default:
			System.out.println("Opção inválida. Tente novamente.");
		}

	}

	public subCategoria() {
		this.subCategoriaMenu();
	}
}
