package view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import dao.HospedeDAO;
import domain.Hospede;

public class subHospede {
	Scanner scanner = new Scanner(System.in);

	public void subHospedeMenu() {
		HospedeDAO hospedeDAO = new HospedeDAO();
		System.out.println("===== MENU " + "HOSPEDE" + " =====");
		System.out.println("1. Consultar");
		System.out.println("2. Editar");
		System.out.println("3. Cadastrar");
		System.out.println("4. Listar");
		System.out.println("0. Voltar");
		System.out.print("Escolha uma opção: ");
		int choice = scanner.nextInt();
		scanner.nextLine();

		switch (choice) {
		case 0:
			new Menu();
			break;
		case 1:
			System.out.print("Insira o CPF do Hospede: ");
			String Codigo1 = scanner.nextLine();
			scanner.nextLine();
			Hospede instancia = new Hospede();
			instancia.setCPF(Codigo1);
			try {
				instancia = hospedeDAO.consultar(instancia);
				System.out.println(instancia.toString());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subHospedeMenu();
			break;
		case 2:
			Hospede newHospede = new Hospede();
			System.out.print("Insira o CPF da Hospede: ");
			String CPF = scanner.nextLine();
			newHospede.setCPF(CPF);
			scanner.nextLine();

			System.out.print("Insira o nome do Hospede: ");
			String DS = scanner.nextLine();
			newHospede.setNome(DS);
			scanner.nextLine();

			System.out.print("Insira o email do Hospede: ");
			String DS1 = scanner.nextLine();
			newHospede.setEmail(DS1);
			scanner.nextLine();

			System.out.print("Insira o endereco do Hospede: ");
			String DS11 = scanner.nextLine();
			newHospede.setEnderecoCompleto(DS11);
			scanner.nextLine();

			try {
				boolean teste = hospedeDAO.editar(newHospede);
				if (teste) {
					System.out.println("Editado com sucesso");
				} else {
					System.out.println("Falha ao editar");
				}

			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subHospedeMenu();
			break;
		case 3:
			Hospede newHospede1 = new Hospede();
			System.out.print("Insira o CPF da Hospede: ");
			String CPF1 = scanner.nextLine();
			newHospede1.setCPF(CPF1);
			scanner.nextLine();

			System.out.print("Insira o nome do Hospede: ");
			String DS112 = scanner.nextLine();
			newHospede1.setNome(DS112);
			scanner.nextLine();

			System.out.print("Insira o email do Hospede: ");
			String DS111 = scanner.nextLine();
			newHospede1.setEmail(DS111);
			scanner.nextLine();

			System.out.print("Insira o endereco do Hospede: ");
			String DS1111 = scanner.nextLine();
			newHospede1.setEnderecoCompleto(DS1111);
			scanner.nextLine();

			try {
				hospedeDAO.cadastrar(newHospede1);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto já existe no cadastro");
			}
			this.subHospedeMenu();
			break;
		case 4:
			Hospede a = new Hospede();
			try {
				ArrayList<Hospede> b = hospedeDAO.listar(a);
				for (Hospede c : b) {
					System.out.println(c.toString());
				}
				this.subHospedeMenu();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subHospedeMenu();
			break;
		default:
			System.out.println("Opção inválida. Tente novamente.");
		}

	}

	public subHospede() {
		this.subHospedeMenu();
	}
}
