package view;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

import dao.ConsumoDAO;
import dao.ItemDAO;
import dao.ReservaDAO;
import domain.Consumo;
import domain.Item;
import domain.Reserva;

public class subConsumo {
	Scanner scanner = new Scanner(System.in);

	public void subConsumoMenu() {
		ConsumoDAO consumoDAO = new ConsumoDAO();
		System.out.println("===== MENU " + "Consumo" + " =====");
		System.out.println("1. Consultar");
		System.out.println("2. Editar");
		System.out.println("3. Cadastrar");
		System.out.println("4. Listar");
		System.out.println("0. Voltar");
		System.out.print("Escolha uma opção: ");

		int choice = scanner.nextInt();
		scanner.nextLine(); // Consumir a nova linha

		switch (choice) {
		case 0:
			new Menu();
			break;
		case 1:
			Consumo instancia = new Consumo();
			System.out.print("Insira o Código do Item: ");
			int Codigo1 = scanner.nextInt();
			scanner.nextLine();
			Item newItem = new Item();
			newItem.setCodigo(Codigo1);
			ItemDAO sDAO = new ItemDAO();
			try {
				newItem = sDAO.consultar(newItem);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			instancia.setItem(newItem);

			System.out.print("Insira o Código da Reserva: ");
			int Codigo2 = scanner.nextInt();
			scanner.nextLine();
			Reserva newReserva = new Reserva();
			newReserva.setCodigo(Codigo2);
			ReservaDAO qDAO = new ReservaDAO();
			try {
				newReserva = qDAO.consultar(newReserva);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			instancia.setReserva(newReserva);

			try {
				instancia = consumoDAO.consultar(instancia);
				System.out.println(instancia.toString());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subConsumoMenu();
			break;
		case 2:
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			Consumo instancia1 = new Consumo();
			try {
				System.out.print("Insira o Código do Item: ");
				int Codigo11 = scanner.nextInt();
				scanner.nextLine();
				Item newItem1 = new Item();
				newItem1.setCodigo(Codigo11);
				ItemDAO sDAO1 = new ItemDAO();
				try {
					newItem1 = sDAO1.consultar(newItem1);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				instancia1.setItem(newItem1);

				System.out.print("Insira o Código da Reserva: ");
				int Codigo21 = scanner.nextInt();
				scanner.nextLine();
				Reserva newReserva1 = new Reserva();
				newReserva1.setCodigo(Codigo21);
				ReservaDAO qDAO1 = new ReservaDAO();
				try {
					newReserva1 = qDAO1.consultar(newReserva1);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				instancia1.setReserva(newReserva1);

				System.out.print("Insira a Quantia solicitada: ");
				int Codigo311 = scanner.nextInt();
				scanner.nextLine();
				instancia1.setQuantidadeSolicitada(Codigo311);

				System.out.print("Insira a data (dd/MM/yyyy): ");
				String entradaConsumo = scanner.nextLine();
				instancia1.setDataConsumo(dateFormat.parse(entradaConsumo));

				// Aqui você pode salvar ou processar a consumo conforme necessário
			} catch (ParseException e) {
				System.out.println("Erro ao converter a data. Certifique-se de usar o formato dd/MM/yyyy.");
			}

			try {
				boolean teste = consumoDAO.editar(instancia1);
				if (teste) {
					System.out.println("Editado com sucesso");
				} else {
					System.out.println("Falha ao editar");
				}

			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subConsumoMenu();
			break;
		case 3:
			SimpleDateFormat dateFormat1 = new SimpleDateFormat("dd/MM/yyyy");
			Consumo instancia11 = new Consumo();
			try {
				System.out.print("Insira o Código do Item: ");
				int Codigo11 = scanner.nextInt();
				scanner.nextLine();
				Item newItem1 = new Item();
				newItem1.setCodigo(Codigo11);
				ItemDAO sDAO1 = new ItemDAO();
				try {
					newItem1 = sDAO1.consultar(newItem1);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				instancia11.setItem(newItem1);

				System.out.print("Insira o Código da Reserva: ");
				int Codigo21 = scanner.nextInt();
				scanner.nextLine();
				Reserva newReserva1 = new Reserva();
				newReserva1.setCodigo(Codigo21);
				ReservaDAO qDAO1 = new ReservaDAO();
				try {
					newReserva1 = qDAO1.consultar(newReserva1);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				System.out.print("Insira a Quantia solicitada: ");
				int Codigo311 = scanner.nextInt();
				scanner.nextLine();
				instancia11.setQuantidadeSolicitada(Codigo311);

				System.out.print("Insira a data (dd/MM/yyyy): ");
				String entradaConsumo = scanner.nextLine();
				instancia11.setDataConsumo(dateFormat1.parse(entradaConsumo));

			} catch (ParseException e) {
				System.out.println("Erro ao converter a data. Certifique-se de usar o formato dd/MM/yyyy.");
			}

			try {
				consumoDAO.cadastrar(instancia11);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto já existe no cadastro");
			}
			this.subConsumoMenu();
			break;
		case 4:
			Consumo a = new Consumo();
			try {
				ArrayList<Consumo> b = consumoDAO.listar(a);
				for (Consumo c : b) {
					System.out.println(c.toString());
				}
				this.subConsumoMenu();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subConsumoMenu();
			break;
		default:
			System.out.println("Opção inválida. Tente novamente.");
		}

	}

	public subConsumo() {
		this.subConsumoMenu();
	}
}
