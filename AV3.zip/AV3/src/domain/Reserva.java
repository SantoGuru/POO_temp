package domain;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import dao.FuncionarioDAO;
import dao.HospedeDAO;
import dao.QuartoDAO;

public class Reserva {
	private int codigo;
	private Hospede hospede;
	private Quarto quarto;
	private Funcionario funcionarioReserva;
	private Funcionario funcionarioFechamento;
	private Date dataEntradaReserva;
	private Date dataSaidaReserva;
	private Date dataCheckin;
	private Date dataCheckout;
	private double valorReserva;
	private double valorPago;

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public Hospede getHospede() {
		return hospede;
	}

	public void setHospede(Hospede hospede) {
		this.hospede = hospede;
	}

	public Quarto getQuarto() {
		return quarto;
	}

	public void setQuarto(Quarto quarto) {
		this.quarto = quarto;
	}

	public Funcionario getFuncionarioReserva() {
		return funcionarioReserva;
	}

	public void setFuncionarioReserva(Funcionario funcionarioReserva) {
		this.funcionarioReserva = funcionarioReserva;
	}

	public Funcionario getFuncionarioFechamento() {
		return funcionarioFechamento;
	}

	public void setFuncionarioFechamento(Funcionario funcionarioFechamento) {
		this.funcionarioFechamento = funcionarioFechamento;
	}

	public Date getDataEntradaReserva() {
		return dataEntradaReserva;
	}

	public void setDataEntradaReserva(Date dataEntradaReserva) {
		this.dataEntradaReserva = dataEntradaReserva;
	}

	public Date getDataSaidaReserva() {
		return dataSaidaReserva;
	}

	public void setDataSaidaReserva(Date dataSaidaReserva) {
		this.dataSaidaReserva = dataSaidaReserva;
	}

	public Date getDataCheckin() {
		return dataCheckin;
	}

	public void setDataCheckin(Date dataCheckin) {
		this.dataCheckin = dataCheckin;
	}

	public Date getDataCheckout() {
		return dataCheckout;
	}

	public void setDataCheckout(Date dataCheckout) {
		this.dataCheckout = dataCheckout;
	}

	public double getValorReserva() {
		return valorReserva;
	}

	public void setValorReserva(double valorReserva) {
		this.valorReserva = valorReserva;
	}

	public double getValorPago() {
		return valorPago;
	}

	public void setValorPago(double valorPago) {
		this.valorPago = valorPago;
	}

	@Override
	public String toString() {
		return this.getCodigo() + "," + this.getHospede().getCPF() + "," + this.getQuarto().getCodigo() + ","
				+ this.getFuncionarioReserva().getCPF() + "," + this.getFuncionarioFechamento().getCPF() + ","
				+ this.getDataEntradaReserva() + "," + this.getDataSaidaReserva() + "," + this.getDataCheckin() + ","
				+ this.getDataCheckout() + "," + this.getValorReserva() + "," + this.getValorPago();
	};

	public Reserva toObject(String s) {
		String[] dados = s.split(",");
		if (dados.length == 11) {
			this.setCodigo(Integer.parseInt(dados[0]));

			// Hospede
			Hospede hospede = new Hospede();
			hospede.setCPF(dados[1]);
			HospedeDAO hospedeDAO = new HospedeDAO();
			try {
				hospede = hospedeDAO.consultar(hospede);
				this.setHospede(hospede);
			} catch (IOException e) {
				e.printStackTrace();
			}

			// Quarto
			Quarto quarto = new Quarto();
			quarto.setCodigo(Integer.parseInt(dados[2]));
			QuartoDAO quartoDAO = new QuartoDAO();
			try {
				quarto = quartoDAO.consultar(quarto);
				this.setQuarto(quarto);
			} catch (IOException e) {
				e.printStackTrace();
			}

			// Funcionario
			Funcionario funcionario = new Funcionario();
			funcionario.setCPF(dados[3]);
			FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
			try {
				funcionario = funcionarioDAO.consultar(funcionario);
				this.setFuncionarioReserva(funcionario);
				this.setFuncionarioFechamento(funcionario);
			} catch (IOException e) {
				e.printStackTrace();
			}

			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			try {
				this.setDataEntradaReserva(formatter.parse(dados[5]));
				this.setDataSaidaReserva(formatter.parse(dados[6]));
				this.setDataCheckin(formatter.parse(dados[7]));
				this.setDataCheckout(formatter.parse(dados[8]));
			} catch (ParseException e) {
				e.printStackTrace();
				System.out.println("Formato de data inválido: " + e.getMessage());
			}
			this.setValorReserva(Double.parseDouble(dados[9]));
			this.setValorPago(Double.parseDouble(dados[10]));
			return this;
		} else {
			System.out.println("Classe: " + this.getClass().getName() + "\nERRO: String de entrada inválida.");
			return null;
		}
	}

	public Reserva(int codigo, Hospede hospede, Quarto quarto, Funcionario funcionarioReserva,
			Funcionario funcionarioFechamento, Date dataEntradaReserva, Date dataSaidaReserva, Date dataCheckin,
			Date dataCheckout, double valorReserva, double valorPago) {
		this.setCodigo(codigo);
		this.setHospede(hospede);
		this.setQuarto(quarto);
		this.setFuncionarioReserva(funcionarioReserva);
		this.setFuncionarioFechamento(funcionarioFechamento);
		this.setDataEntradaReserva(dataEntradaReserva);
		this.setDataSaidaReserva(dataSaidaReserva);
		this.setDataCheckin(dataCheckin);
		this.setDataCheckout(dataCheckout);
		this.setValorReserva(valorReserva);
		this.setValorPago(valorPago);
	}

	public Reserva() {

	}
}
