package domain;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import dao.CategoriaDAO;
import dao.ReservaDAO;
import dao.ServicoDAO;

public class ConsumoServico {
	private Servico servico;
	private Categoria categoria;
	private Reserva reserva;
	private int quantidadeSolicitada;
	private Date dataServico;

	public Servico getServico() {
		return servico;
	}

	public void setServico(Servico servico) {
		this.servico = servico;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public Reserva getReserva() {
		return reserva;
	}

	public void setReserva(Reserva reserva) {
		this.reserva = reserva;
	}

	public int getQuantidadeSolicitada() {
		return quantidadeSolicitada;
	}

	public void setQuantidadeSolicitada(int quantidadeSolicitada) {
		this.quantidadeSolicitada = quantidadeSolicitada;
	}

	public Date getDataServico() {
		return dataServico;
	}

	public void setDataServico(Date dataServico) {
		this.dataServico = dataServico;
	}

	public ConsumoServico(Servico servico, Categoria categoria, Reserva reserva, int quantidadeSolicitada,
			Date dataServico) {
		this.setServico(servico);
		this.setCategoria(categoria);
		this.setReserva(reserva);
		this.setQuantidadeSolicitada(quantidadeSolicitada);
		this.setDataServico(dataServico);
	}

	public ConsumoServico() {
	}

	@Override
	public String toString() {
		return this.getServico().getCodigo() + "," + this.getCategoria().getCodigo() + ","
				+ this.getReserva().getCodigo() + "," + this.getQuantidadeSolicitada() + "," + this.getDataServico();
	};

	public ConsumoServico toObject(String s) {
		String[] dados = s.split(",");
		if (dados.length == 3) {
			// Servico
			Servico servico = new Servico();
			servico.setCodigo(Integer.parseInt(dados[0]));
			ServicoDAO servicoDAO = new ServicoDAO();
			try {
				servico = servicoDAO.consultar(servico);
				this.setServico(servico);
			} catch (IOException e) {

				e.printStackTrace();
			}
			// Categoria
			Categoria categoria = new Categoria();
			categoria.setCodigo(Integer.parseInt(dados[1]));
			CategoriaDAO categoriaDAO = new CategoriaDAO();
			try {
				categoria = categoriaDAO.consultar(categoria);
				this.setCategoria(categoria);
			} catch (IOException e) {
				e.printStackTrace();
			}
			// Reserva
			Reserva reserva = new Reserva();
			reserva.setCodigo(Integer.parseInt(dados[2]));
			ReservaDAO reservaDAO = new ReservaDAO();
			try {
				reserva = reservaDAO.consultar(reserva);
				this.setReserva(reserva);
			} catch (IOException e) {
				e.printStackTrace();
			}
			this.setReserva(reserva);
			// Resto
			this.setQuantidadeSolicitada(Integer.parseInt(dados[3]));
			SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");
			try {
				Date newdate = SDF.parse(dados[4]);
				this.setDataServico(newdate);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			return this;
		} else {
			System.out.println("Classe: " + this.getClass().getName() + "\nERRO: String de entrada inválida.");
			return null;
		}
	}
}
