package domain;

import java.io.IOException;

import dao.CategoriaDAO;
import dao.ItemDAO;

public class CategoriaItem {
	private Item item;
	private Categoria categoria;
	private int quantidade;

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	};

	public CategoriaItem(Item item, Categoria categoria, int quantidade) {
		this.setItem(item);
		this.setCategoria(categoria);
		this.setQuantidade(quantidade);
	}

	public CategoriaItem() {

	}

	@Override
	public String toString() {
		return this.getItem().getCodigo() + "," + this.getCategoria().getCodigo() + "," + this.getQuantidade();
	};

	public CategoriaItem toObject(String s) {
		String[] dados = s.split(",");
		if (dados.length == 3) {
			Item item = new Item();
			item.setCodigo(Integer.parseInt(dados[0]));
			ItemDAO itemDAO = new ItemDAO();
			try {
				item = itemDAO.consultar(item);
				this.setItem(item);
			} catch (IOException e) {
				e.printStackTrace();
			}
			Categoria categoria = new Categoria();
			CategoriaDAO categoriaDAO = new CategoriaDAO();
			categoria.setCodigo(Integer.parseInt(dados[1]));
			try {
				categoria = categoriaDAO.consultar(categoria);
				this.setCategoria(categoria);
			} catch (IOException e) {
				e.printStackTrace();
			}
			this.setQuantidade(Integer.parseInt(dados[2]));
			return this;
		} else {
			System.out.println("Classe: " + this.getClass().getName() + "\nERRO: String de entrada inválida.");
			return null;
		}
	}
}
