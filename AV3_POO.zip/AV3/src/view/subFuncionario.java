package view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import dao.FuncionarioDAO;
import domain.Funcionario;

public class subFuncionario {
	Scanner scanner = new Scanner(System.in);

	public void subFuncionarioMenu() {
		FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		System.out.println("===== MENU " + "FUNCIONARIO" + " =====");
		System.out.println("1. Consultar");
		System.out.println("2. Editar");
		System.out.println("3. Cadastrar");
		System.out.println("4. Listar");
		System.out.println("0. Voltar");
		System.out.print("Escolha uma opção: ");
		int choice = scanner.nextInt();
		scanner.nextLine();

		switch (choice) {
		case 0:
			new Menu();
			break;
		case 1:
			System.out.print("Insira o CPF do Funcionario: ");
			String Codigo1 = scanner.nextLine();
			scanner.nextLine();
			Funcionario instancia = new Funcionario();
			instancia.setCPF(Codigo1);
			try {
				instancia = funcionarioDAO.consultar(instancia);
				System.out.println(instancia.toString());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subFuncionarioMenu();
			break;
		case 2:
			Funcionario newFuncionario = new Funcionario();
			System.out.print("Insira o CPF da Funcionario: ");
			String CPF = scanner.nextLine();
			newFuncionario.setCPF(CPF);
			scanner.nextLine();

			System.out.print("Insira o nome do Funcionario: ");
			String DS = scanner.nextLine();
			newFuncionario.setNome(DS);
			scanner.nextLine();

			System.out.print("Insira o email do Funcionario: ");
			String DS1 = scanner.nextLine();
			newFuncionario.setEmail(DS1);
			scanner.nextLine();

			System.out.print("Insira o setor do Funcionario: ");
			String DS11 = scanner.nextLine();
			newFuncionario.setSetor(DS11);
			scanner.nextLine();

			try {
				boolean teste = funcionarioDAO.editar(newFuncionario);
				if (teste) {
					System.out.println("Editado com sucesso");
				} else {
					System.out.println("Falha ao editar");
				}

			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subFuncionarioMenu();
			break;
		case 3:
			Funcionario newFuncionario1 = new Funcionario();
			System.out.print("Insira o CPF da Funcionario: ");
			String CPF1 = scanner.nextLine();
			newFuncionario1.setCPF(CPF1);
			scanner.nextLine();

			System.out.print("Insira o nome do Funcionario: ");
			String DS112 = scanner.nextLine();
			newFuncionario1.setNome(DS112);
			scanner.nextLine();

			System.out.print("Insira o email do Funcionario: ");
			String DS111 = scanner.nextLine();
			newFuncionario1.setEmail(DS111);
			scanner.nextLine();

			System.out.print("Insira o Setor do Funcionario: ");
			String DS1111 = scanner.nextLine();
			newFuncionario1.setSetor(DS1111);
			scanner.nextLine();

			try {
				funcionarioDAO.cadastrar(newFuncionario1);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto já existe no cadastro");
			}
			this.subFuncionarioMenu();
			break;
		case 4:
			Funcionario a = new Funcionario();
			try {
				ArrayList<Funcionario> b = funcionarioDAO.listar(a);
				for (Funcionario c : b) {
					System.out.println(c.toString());
				}
				this.subFuncionarioMenu();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subFuncionarioMenu();
			break;
		default:
			System.out.println("Opção inválida. Tente novamente.");
		}

	}

	public subFuncionario() {
		this.subFuncionarioMenu();
	}
}
