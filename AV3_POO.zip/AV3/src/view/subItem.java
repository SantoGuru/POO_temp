package view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import dao.ItemDAO;
import domain.Item;

public class subItem {
	Scanner scanner = new Scanner(System.in);

	public void subItemMenu() {
		ItemDAO itemDAO = new ItemDAO();
		System.out.println("===== MENU " + "ITEM" + " =====");
		System.out.println("1. Consultar");
		System.out.println("2. Editar");
		System.out.println("3. Cadastrar");
		System.out.println("4. Listar");
		System.out.println("0. Voltar");
		System.out.print("Escolha uma opção: ");
		int choice = scanner.nextInt();
		scanner.nextLine();

		switch (choice) {
		case 0:
			new Menu();
			break;
		case 1:
			System.out.print("Insira o Código do Item: ");
			int Codigo1 = scanner.nextInt();
			scanner.nextLine();
			Item instancia = new Item();
			instancia.setCodigo(Codigo1);
			try {
				instancia = itemDAO.consultar(instancia);
				System.out.println(instancia.toString());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subItemMenu();
			break;
		case 2:
			Item newItem = new Item();
			System.out.print("Insira o ID da Item: ");
			int ID = scanner.nextInt();
			newItem.setCodigo(ID);
			scanner.nextLine();

			System.out.print("Insira a Descrição do Item: ");
			String DS = scanner.nextLine();
			newItem.setDescricao(DS);
			scanner.nextLine();

			System.out.print("Insira o valor do Item: ");
			Double DS1 = scanner.nextDouble();
			newItem.setValor(DS1);
			scanner.nextLine();

			try {
				boolean teste = itemDAO.editar(newItem);
				if (teste) {
					System.out.println("Editado com sucesso");
				} else {
					System.out.println("Falha ao editar");
				}

			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subItemMenu();
			break;
		case 3:
			Item newItem1 = new Item();
			System.out.print("Insira o ID da Item: ");
			int ID1 = scanner.nextInt();
			newItem1.setCodigo(ID1);
			scanner.nextLine();

			System.out.print("Insira a Descrição do Item: ");
			String DS11 = scanner.nextLine();
			newItem1.setDescricao(DS11);
			scanner.nextLine();

			System.out.print("Insira o valor do Item: ");
			Double DS111 = scanner.nextDouble();
			newItem1.setValor(DS111);
			scanner.nextLine();
			try {
				itemDAO.cadastrar(newItem1);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto já existe no cadastro");
			}
			this.subItemMenu();
			break;
		case 4:
			Item a = new Item();
			try {
				ArrayList<Item> b = itemDAO.listar(a);
				for (Item c : b) {
					System.out.println(c.toString());
				}
				this.subItemMenu();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subItemMenu();
			break;
		default:
			System.out.println("Opção inválida. Tente novamente.");
		}

	}

	public subItem() {
		this.subItemMenu();
	}
}
