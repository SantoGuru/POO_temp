package view;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

import dao.CategoriaDAO;
import dao.ConsumoServicoDAO;
import dao.ReservaDAO;
import dao.ServicoDAO;
import domain.Categoria;
import domain.ConsumoServico;
import domain.Reserva;
import domain.Servico;

public class subConsumoServico {
	Scanner scanner = new Scanner(System.in);

	public void subConsumoServicoMenu() {
		ConsumoServicoDAO consumoServicoDAO = new ConsumoServicoDAO();
		System.out.println("===== MENU " + "ConsumoServico" + " =====");
		System.out.println("1. Consultar");
		System.out.println("2. Editar");
		System.out.println("3. Cadastrar");
		System.out.println("4. Listar");
		System.out.println("0. Voltar");
		System.out.print("Escolha uma opção: ");

		int choice = scanner.nextInt();
		scanner.nextLine(); // Consumir a nova linha

		switch (choice) {
		case 0:
			new Menu();
			break;
		case 1:
			ConsumoServico instancia = new ConsumoServico();
			System.out.print("Insira o Código do Servico: ");
			int Codigo1 = scanner.nextInt();
			scanner.nextLine();
			Servico newServico = new Servico();
			newServico.setCodigo(Codigo1);
			ServicoDAO sDAO = new ServicoDAO();
			try {
				newServico = sDAO.consultar(newServico);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			instancia.setServico(newServico);

			System.out.print("Insira o Código da Categoria: ");
			int Codigo2 = scanner.nextInt();
			scanner.nextLine();
			Categoria newCategoria = new Categoria();
			newCategoria.setCodigo(Codigo2);
			CategoriaDAO qDAO = new CategoriaDAO();
			try {
				newCategoria = qDAO.consultar(newCategoria);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			instancia.setCategoria(newCategoria);

			System.out.print("Insira o Código da Reserva: ");
			int Codigo3 = scanner.nextInt();
			scanner.nextLine();
			Reserva newReserva = new Reserva();
			newReserva.setCodigo(Codigo3);
			ReservaDAO rDAO = new ReservaDAO();
			try {
				newReserva = rDAO.consultar(newReserva);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			instancia.setReserva(newReserva);

			try {
				instancia = consumoServicoDAO.consultar(instancia);
				System.out.println(instancia.toString());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subConsumoServicoMenu();
			break;
		case 2:
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			ConsumoServico instancia1 = new ConsumoServico();
			try {
				System.out.print("Insira o Código do Servico: ");
				int Codigo11 = scanner.nextInt();
				scanner.nextLine();
				Servico newServico1 = new Servico();
				newServico1.setCodigo(Codigo11);
				ServicoDAO sDAO1 = new ServicoDAO();
				newServico1 = sDAO1.consultar(newServico1);

				instancia1.setServico(newServico1);

				System.out.print("Insira o Código da Categoria: ");
				int Codigo21 = scanner.nextInt();
				scanner.nextLine();
				Categoria newCategoria1 = new Categoria();
				newCategoria1.setCodigo(Codigo21);
				CategoriaDAO qDAO1 = new CategoriaDAO();
				newCategoria1 = qDAO1.consultar(newCategoria1);

				instancia1.setCategoria(newCategoria1);

				System.out.print("Insira o Código da Reserva: ");
				int Codigo31 = scanner.nextInt();
				scanner.nextLine();
				Reserva newReserva1 = new Reserva();
				newReserva1.setCodigo(Codigo31);
				ReservaDAO rDAO1 = new ReservaDAO();
				newReserva1 = rDAO1.consultar(newReserva1);

				instancia1.setReserva(newReserva1);

				System.out.print("Insira a Quantia solicitada: ");
				int Codigo311 = scanner.nextInt();
				scanner.nextLine();
				instancia1.setQuantidadeSolicitada(Codigo311);

				System.out.print("Insira a data (dd/MM/yyyy): ");
				String entradaConsumoServico = scanner.nextLine();
				instancia1.setDataServico(dateFormat.parse(entradaConsumoServico));

				// Aqui você pode salvar ou processar a consumoServico conforme necessário
			} catch (ParseException e) {
				System.out.println("Erro ao converter a data. Certifique-se de usar o formato dd/MM/yyyy.");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				boolean teste = consumoServicoDAO.editar(instancia1);
				if (teste) {
					System.out.println("Editado com sucesso");
				} else {
					System.out.println("Falha ao editar");
				}

			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subConsumoServicoMenu();
			break;
		case 3:
			SimpleDateFormat dateFormat1 = new SimpleDateFormat("dd/MM/yyyy");
			ConsumoServico instancia11 = new ConsumoServico();
			try {
				System.out.print("Insira o Código do Servico: ");
				int Codigo11 = scanner.nextInt();
				scanner.nextLine();
				Servico newServico1 = new Servico();
				newServico1.setCodigo(Codigo11);
				ServicoDAO sDAO1 = new ServicoDAO();
				newServico1 = sDAO1.consultar(newServico1);

				instancia11.setServico(newServico1);

				System.out.print("Insira o Código da Categoria: ");
				int Codigo21 = scanner.nextInt();
				scanner.nextLine();
				Categoria newCategoria1 = new Categoria();
				newCategoria1.setCodigo(Codigo21);
				CategoriaDAO qDAO1 = new CategoriaDAO();
				newCategoria1 = qDAO1.consultar(newCategoria1);

				instancia11.setCategoria(newCategoria1);

				System.out.print("Insira o Código da Reserva: ");
				int Codigo31 = scanner.nextInt();
				scanner.nextLine();
				Reserva newReserva1 = new Reserva();
				newReserva1.setCodigo(Codigo31);
				ReservaDAO rDAO1 = new ReservaDAO();
				newReserva1 = rDAO1.consultar(newReserva1);

				instancia11.setReserva(newReserva1);

				System.out.print("Insira a Quantia solicitada: ");
				int Codigo311 = scanner.nextInt();
				scanner.nextLine();
				instancia11.setQuantidadeSolicitada(Codigo311);

				System.out.print("Insira a data (dd/MM/yyyy): ");
				String entradaConsumoServico = scanner.nextLine();
				instancia11.setDataServico(dateFormat1.parse(entradaConsumoServico));
			} catch (ParseException e) {
				System.out.println("Erro ao converter a data. Certifique-se de usar o formato dd/MM/yyyy.");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				consumoServicoDAO.cadastrar(instancia11);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto já existe no cadastro");
			}
			this.subConsumoServicoMenu();
			break;
		case 4:
			ConsumoServico a = new ConsumoServico();
			try {
				ArrayList<ConsumoServico> b = consumoServicoDAO.listar(a);
				for (ConsumoServico c : b) {
					System.out.println(c.toString());
				}
				this.subConsumoServicoMenu();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subConsumoServicoMenu();
			break;
		default:
			System.out.println("Opção inválida. Tente novamente.");
		}

	}

	public subConsumoServico() {
		this.subConsumoServicoMenu();
	}
}
