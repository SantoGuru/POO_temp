package view;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

import dao.FuncionarioDAO;
import dao.HospedeDAO;
import dao.QuartoDAO;
import dao.ReservaDAO;
import domain.Funcionario;
import domain.Hospede;
import domain.Quarto;
import domain.Reserva;

public class subReserva {
	Scanner scanner = new Scanner(System.in);

	public void subReservaMenu() {
		ReservaDAO reservaDAO = new ReservaDAO();
		System.out.println("===== MENU " + "RESERVA" + " =====");
		System.out.println("1. Consultar");
		System.out.println("2. Editar");
		System.out.println("3. Cadastrar");
		System.out.println("4. Listar");
		System.out.println("5. Pagar");
		System.out.println("0. Voltar");
		System.out.print("Escolha uma opção: ");
		int choice = scanner.nextInt();
		scanner.nextLine(); // Consumir a nova linha

		switch (choice) {
		case 0:
			new Menu();
			break;
		case 1:
			System.out.print("Insira o Código do Reserva: ");
			int Codigo1 = scanner.nextInt();
			scanner.nextLine();
			Reserva instancia = new Reserva();
			instancia.setCodigo(Codigo1);
			try {
				instancia = reservaDAO.consultar(instancia);
				System.out.println(instancia.toString());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subReservaMenu();
			break;
		case 2:
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			Reserva newReserva = new Reserva();
			try {
				System.out.print("Insira o ID da Reserva: ");
				int ID = scanner.nextInt();
				newReserva.setCodigo(ID);
				scanner.nextLine();
				System.out.print("Insira o CPF do Hospede: ");
				String CPF = scanner.nextLine();
				Hospede h = new Hospede();
				h.setCPF(CPF);
				HospedeDAO hDAO = new HospedeDAO();
				newReserva.setHospede(hDAO.consultar(h));

				System.out.print("Insira o ID do Quarto: ");
				int idQuarto = scanner.nextInt();
				scanner.nextLine(); // Consumir a nova linha
				Quarto q = new Quarto();
				q.setCodigo(idQuarto);
				QuartoDAO qDAO = new QuartoDAO();
				newReserva.setQuarto(qDAO.consultar(q));

				System.out.print("Insira o ID do Funcionario que fez a reserva: ");
				String idFuncionarioReserva = scanner.nextLine();
				scanner.nextLine();
				Funcionario fReserva = new Funcionario();
				fReserva.setCPF(idFuncionarioReserva);
				FuncionarioDAO fReservaDAO = new FuncionarioDAO();
				newReserva.setFuncionarioReserva(fReservaDAO.consultar(fReserva));

				newReserva.setFuncionarioFechamento(new Funcionario("", "", "", ""));

				System.out.print("Insira a data de entrada da reserva (dd/MM/yyyy): ");
				String entradaReserva = scanner.nextLine();
				newReserva.setDataEntradaReserva(dateFormat.parse(entradaReserva));

				System.out.print("Insira a data de saída da reserva (dd/MM/yyyy): ");
				String saidaReserva = scanner.nextLine();
				newReserva.setDataSaidaReserva(dateFormat.parse(saidaReserva));

				System.out.print("Insira a data de check-in (dd/MM/yyyy): ");
				String checkin = scanner.nextLine();
				newReserva.setDataCheckin(dateFormat.parse(checkin));

				System.out.print("Insira o valor da reserva: ");
				double valorReserva = scanner.nextDouble();
				newReserva.setValorReserva(valorReserva);

				// Aqui você pode salvar ou processar a reserva conforme necessário
			} catch (ParseException e) {
				System.out.println("Erro ao converter a data. Certifique-se de usar o formato dd/MM/yyyy.");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				boolean teste = reservaDAO.editar(newReserva);
				if (teste) {
					System.out.println("Editado com sucesso");
				} else {
					System.out.println("Falha ao editar");
				}

			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subReservaMenu();
			break;
		case 3:

			SimpleDateFormat dateFormat1 = new SimpleDateFormat("dd/MM/yyyy");
			Reserva newReserva1 = new Reserva();
			try {
				System.out.print("Insira o ID da Reserva: ");
				int ID = scanner.nextInt();
				newReserva1.setCodigo(ID);
				scanner.nextLine();

				System.out.print("Insira o CPF do Hospede: ");
				String CPF = scanner.nextLine();
				Hospede h = new Hospede();
				h.setCPF(CPF);
				HospedeDAO hDAO = new HospedeDAO();
				newReserva1.setHospede(hDAO.consultar(h));

				System.out.print("Insira o ID do Quarto: ");
				int idQuarto = scanner.nextInt();
				scanner.nextLine(); // Consumir a nova linha
				Quarto q = new Quarto();
				q.setCodigo(idQuarto);
				QuartoDAO qDAO = new QuartoDAO();
				newReserva1.setQuarto(qDAO.consultar(q));

				System.out.print("Insira o ID do Funcionario que fez a reserva: ");
				String idFuncionarioReserva = scanner.nextLine();
				scanner.nextLine();
				Funcionario fReserva = new Funcionario();
				fReserva.setCPF(idFuncionarioReserva);
				FuncionarioDAO fReservaDAO = new FuncionarioDAO();
				newReserva1.setFuncionarioReserva(fReservaDAO.consultar(fReserva));

				newReserva1.setFuncionarioFechamento(new Funcionario("", "", "", ""));

				System.out.print("Insira a data de entrada da reserva (dd/MM/yyyy): ");
				String entradaReserva = scanner.nextLine();
				newReserva1.setDataEntradaReserva(dateFormat1.parse(entradaReserva));

				System.out.print("Insira a data de saída da reserva (dd/MM/yyyy): ");
				String saidaReserva = scanner.nextLine();
				newReserva1.setDataSaidaReserva(dateFormat1.parse(saidaReserva));

				System.out.print("Insira a data de check-in (dd/MM/yyyy): ");
				String checkin = scanner.nextLine();
				newReserva1.setDataCheckin(dateFormat1.parse(checkin));

				System.out.print("Insira o valor da reserva: ");
				double valorReserva = scanner.nextDouble();
				newReserva1.setValorReserva(valorReserva);

				// Aqui você pode salvar ou processar a reserva conforme necessário
			} catch (ParseException e) {
				System.out.println("Erro ao converter a data. Certifique-se de usar o formato dd/MM/yyyy.");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				reservaDAO.cadastrar(newReserva1);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto já existe no cadastro");
			}
			this.subReservaMenu();
			break;
		case 4:
			Reserva a = new Reserva();
			try {
				ArrayList<Reserva> b = reservaDAO.listar(a);
				for (Reserva c : b) {
					System.out.println(c.toString());
				}
				this.subReservaMenu();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				System.out.println("ERROR: O objeto não existe no cadastro");
			}
			this.subReservaMenu();
			break;
		case 5:
			System.out.print("Insira o ID da Reserva: ");
			int ID = scanner.nextInt();
			scanner.nextLine();
			reservaDAO.pagarReserva(ID);
			this.subReservaMenu();
			break;
		default:
			System.out.println("Opção inválida. Tente novamente.");
		}

	}

	public subReserva() {
		this.subReservaMenu();
	}
}
