package view;

import java.util.Scanner;

public class Menu {
	Scanner scanner = new Scanner(System.in);

	public void mainMenu() {
		System.out.println("===== MENU PRINCIPAL =====");
		System.out.println("1. Categoria");
		System.out.println("2. CategoriaItem");
		System.out.println("3. Consumo");
		System.out.println("4. ConsumoServico");
		System.out.println("5. Funcionario");
		System.out.println("6. Hospede");
		System.out.println("7. Item");
		System.out.println("8. Quarto");
		System.out.println("9. Reserva");
		System.out.println("10. Servico");
		System.out.println("0. Sair");
		System.out.print("Escolha uma opção: ");
		int choice = scanner.nextInt();
		scanner.nextLine();

		if (choice == 0) {
			System.out.println("Saindo...");
		}

		switch (choice) {
		case 1:
			// subMenu("Categoria");
			new subCategoria();
			break;
		case 2:
			// subMenu("CategoriaItem");
			new subCategoriaItem();
			break;
		case 3:
			// subMenu("Consumo");
			new subConsumo();
			break;
		case 4:
			// subMenu("ConsumoServico");
			new subConsumoServico();
			break;
		case 5:
			// subMenu("Funcionario");
			new subFuncionario();
			break;
		case 6:
			// subMenu("Hospede");
			new subHospede();
			break;
		case 7:
			// subMenu("Item");
			new subItem();
			break;
		case 8:
			// subMenu("Quarto");
			new subQuarto();
			break;
		case 9:
			// subMenu("Reserva");
			new subReserva();
			break;
		case 10:
			new subServico();
			break;
		default:
			System.out.println("Opção inválida. Tente novamente.");
		}
	};

	public Menu() {
		this.mainMenu();
	}
}
