package domain;

import java.io.IOException;

import dao.CategoriaDAO;

public class Quarto {
	private int codigo;
	private Categoria categoria;
	private String status;

	// IMPLEMENTAR E DAO
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return this.getCodigo() + "," + this.getCategoria().getCodigo() + "," + this.getStatus();
	};

	public Quarto toObject(String s) {
		String[] dados = s.split(",");
		if (dados.length == 3) {
			this.setCodigo(Integer.parseInt(dados[0]));
			Categoria categoria = new Categoria();
			CategoriaDAO categoriaDAO = new CategoriaDAO();
			categoria.setCodigo(codigo);
			try {
				categoria = categoriaDAO.consultar(categoria);
			} catch (IOException e) {
				e.printStackTrace();
			}
			this.setCategoria(categoria);
			this.setStatus(dados[2]);
			return this;
		} else {
			System.out.println("Classe: " + this.getClass().getName() + "\nERRO: String de entrada inválida.");
			return null;
		}
	}

	public Quarto(int codigo, Categoria categoria, String status) {
		this.setCodigo(codigo);
		this.setCategoria(categoria);
		this.setStatus(status);
	}

	public Quarto() {
	};

}
