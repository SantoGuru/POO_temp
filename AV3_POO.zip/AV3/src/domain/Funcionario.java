package domain;

public class Funcionario extends Pessoa {
	private String setor;

	public String getSetor() {
		return setor;
	}

	public void setSetor(String setor) {
		this.setor = setor;
	}

	public Funcionario(String cpf, String nome, String email, String setor) {
		super(cpf, nome, email);
		this.setSetor(setor);
	}

	public Funcionario() {
		super();
	}

	@Override
	public String toString() {
		return this.getCPF() + "," + this.getNome() + "," + this.getEmail() + "," + this.getSetor();
	};

	public Funcionario toObject(String s) {
		String[] dados = s.split(",");
		if (dados.length == 4) {
			this.setCPF(dados[0]);
			this.setNome(dados[1]);
			this.setEmail(dados[2]);
			this.setSetor(dados[3]);
			return this;
		} else {
			System.out.println("Classe: " + this.getClass().getName() + "\nERRO: String de entrada inválida.");
			return null;
		}
	}
}
