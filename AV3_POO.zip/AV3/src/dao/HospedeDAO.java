package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import domain.Hospede;

public class HospedeDAO implements GenericDAO<Hospede> {
	public String ClassName = "Hospede";
	public String filePath = "./Files/";
	public String fileType = ".txt";
	public DataBase DB = new DataBase(new File(filePath + ClassName + fileType));

	@Override
	public Hospede consultar(Hospede hospede) throws IOException {
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			String[] dados = linha.split(",");
			if (dados.length > 0 && dados[0].toString().equals(hospede.getCPF())) {
				Hospede encontrado = new Hospede();
				encontrado.toObject(linha);
				BR.close();
				return encontrado;
			}
		}
		BR.close();
		return null;
	};

	@Override
	public Hospede cadastrar(Hospede hospede) throws IOException {
		Hospede consultaExist = this.consultar(hospede);
		if (consultaExist == null) {
			File file = DB.load(ClassName);
			FileReader FR = new FileReader(file);
			BufferedReader BR = new BufferedReader(FR);
			FileWriter FW = new FileWriter(file, true);
			BufferedWriter BW = new BufferedWriter(FW);
			if (BR.readLine() == null) {
				BW.write(hospede.toString());
			} else {
				BW.newLine();
				BW.write(hospede.toString());
			}
			BR.close();
			BW.close();
			System.out.println("Hospede cadastrado!");
			return hospede;
		} else {
			System.out.println("ERRO: Hospede já cadastrado!");
			return null;
		}
	}

	public ArrayList<Hospede> listar(Hospede hospede) throws IOException {
		ArrayList<Hospede> arrayList = new ArrayList<Hospede>();
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			Hospede Listado = new Hospede();
			Listado.toObject(linha);
			arrayList.add(Listado);
		}
		BR.close();
		return arrayList;
	}

	public boolean editar(Hospede hospede) throws IOException {
		Hospede consultaExist = this.consultar(hospede);
		if (consultaExist != null) {
			ArrayList<Hospede> arrayList = this.listar(null);
			for (int i = 0; i < arrayList.size(); i++) {
				if (arrayList.get(i).getCPF().toString().equals(hospede.getCPF())) {
					arrayList.remove(i);
					arrayList.add(hospede);
					File arquivo = DB.load(ClassName);
					arquivo.delete();
				}
			}
			FileWriter FW = new FileWriter(filePath + ClassName + fileType, true);
			BufferedWriter BW = new BufferedWriter(FW);
			for (Hospede h : arrayList) {
				BW.write(h.toString());
				BW.newLine();
			}
			BW.close();
			return true;
		}
		return false;
	}

}
