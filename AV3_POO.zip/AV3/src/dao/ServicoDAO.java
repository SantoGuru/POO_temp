package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import domain.Servico;

public class ServicoDAO implements GenericDAO<Servico> {
	public String ClassName = "Servico";
	public String filePath = "./Files/";
	public String fileType = ".txt";
	public DataBase DB = new DataBase(new File(filePath + ClassName + fileType));

	@Override
	public Servico consultar(Servico servico) throws IOException {
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			String[] dados = linha.split(",");
			if (dados.length > 0 && Integer.parseInt(dados[0]) == servico.getCodigo()) {
				Servico encontrado = new Servico();
				encontrado.toObject(linha);
				BR.close();
				return encontrado;
			}
		}
		BR.close();
		return null;
	};

	@Override
	public Servico cadastrar(Servico servico) throws IOException {
		Servico consultaExist = this.consultar(servico);
		if (consultaExist == null) {
			File file = DB.load(ClassName);
			FileReader FR = new FileReader(file);
			BufferedReader BR = new BufferedReader(FR);
			FileWriter FW = new FileWriter(file, true);
			BufferedWriter BW = new BufferedWriter(FW);
			if (BR.readLine() == null) {
				BW.write(servico.toString());
			} else {
				BW.newLine();
				BW.write(servico.toString());
			}
			BR.close();
			BW.close();
			System.out.println("Servico cadastrado!");
			return servico;
		} else {
			System.out.println("ERRO: Servico já cadastrado!");
			return null;
		}
	}

	public ArrayList<Servico> listar(Servico servico) throws IOException {
		ArrayList<Servico> arrayList = new ArrayList<Servico>();
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			Servico Listado = new Servico();
			Listado.toObject(linha);
			arrayList.add(Listado);
		}
		BR.close();
		return arrayList;
	}

	public boolean editar(Servico servico) throws IOException {
		Servico consultaExist = this.consultar(servico);
		if (consultaExist != null) {
			ArrayList<Servico> arrayList = this.listar(null);
			for (int i = 0; i < arrayList.size(); i++) {
				if (arrayList.get(i).getCodigo() == (servico.getCodigo())) {
					arrayList.remove(i);
					arrayList.add(servico);
					File arquivo = DB.load(ClassName);
					arquivo.delete();
				}
			}
			FileWriter FW = new FileWriter(filePath + ClassName + fileType, true);
			BufferedWriter BW = new BufferedWriter(FW);
			for (Servico h : arrayList) {
				BW.write(h.toString());
				BW.newLine();
			}
			BW.close();
			return true;
		}
		return false;
	}

}
