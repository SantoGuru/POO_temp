package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import domain.Funcionario;

public class FuncionarioDAO implements GenericDAO<Funcionario> {
	public String ClassName = "Funcionario";
	public String filePath = "./Files/";
	public String fileType = ".txt";
	public DataBase DB = new DataBase(new File(filePath + ClassName + fileType));

	@Override
	public Funcionario consultar(Funcionario funcionario) throws IOException {
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			String[] dados = linha.split(",");
			if (dados.length > 0 && dados[0].toString().equals(funcionario.getCPF())) {
				Funcionario encontrado = new Funcionario();
				encontrado.toObject(linha);
				BR.close();
				return encontrado;
			}
		}
		BR.close();
		return null;
	};

	@Override
	public Funcionario cadastrar(Funcionario funcionario) throws IOException {
		Funcionario consultaExist = this.consultar(funcionario);
		if (consultaExist == null) {
			File file = DB.load(ClassName);
			FileReader FR = new FileReader(file);
			BufferedReader BR = new BufferedReader(FR);
			FileWriter FW = new FileWriter(file, true);
			BufferedWriter BW = new BufferedWriter(FW);
			if (BR.readLine() == null) {
				BW.write(funcionario.toString());
			} else {
				BW.newLine();
				BW.write(funcionario.toString());
			}
			BR.close();
			BW.close();
			System.out.println("Funcionario cadastrado!");
			return funcionario;
		} else {
			System.out.println("ERRO: Funcionario já cadastrado!");
			return null;
		}
	}

	public ArrayList<Funcionario> listar(Funcionario funcionario) throws IOException {
		ArrayList<Funcionario> arrayList = new ArrayList<Funcionario>();
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			Funcionario Listado = new Funcionario();
			Listado.toObject(linha);
			arrayList.add(Listado);
		}
		BR.close();
		return arrayList;
	}

	public boolean editar(Funcionario funcionario) throws IOException {
		Funcionario consultaExist = this.consultar(funcionario);
		if (consultaExist != null) {
			ArrayList<Funcionario> arrayList = this.listar(null);
			for (int i = 0; i < arrayList.size(); i++) {
				if (arrayList.get(i).getCPF().toString().equals(funcionario.getCPF())) {
					arrayList.remove(i);
					arrayList.add(funcionario);
					File arquivo = DB.load(ClassName);
					arquivo.delete();
				}
			}
			FileWriter FW = new FileWriter(filePath + ClassName + fileType, true);
			BufferedWriter BW = new BufferedWriter(FW);
			for (Funcionario h : arrayList) {
				BW.write(h.toString());
				BW.newLine();
			}
			BW.close();
			return true;
		}
		return false;
	}

}
