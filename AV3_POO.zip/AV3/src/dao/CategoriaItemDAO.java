package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import domain.CategoriaItem;

public class CategoriaItemDAO implements GenericDAO<CategoriaItem> {
	public String ClassName = "CategoriaItem";
	public String filePath = "./Files/";
	public String fileType = ".txt";
	public DataBase DB = new DataBase(new File(filePath + ClassName + fileType));

	@Override
	public CategoriaItem consultar(CategoriaItem categoriaItem) throws IOException {
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			String[] dados = linha.split(",");
			if (dados.length > 0 && Integer.parseInt(dados[0]) == categoriaItem.getItem().getCodigo()
					&& Integer.parseInt(dados[1]) == categoriaItem.getCategoria().getCodigo()) {
				CategoriaItem encontrado = new CategoriaItem();
				encontrado.toObject(linha);
				BR.close();
				return encontrado;
			}
		}
		BR.close();
		return null;
	};

	@Override
	public CategoriaItem cadastrar(CategoriaItem categoriaItem) throws IOException {
		CategoriaItem consultaExist = this.consultar(categoriaItem);
		if (consultaExist == null) {
			File file = DB.load(ClassName);
			FileReader FR = new FileReader(file);
			BufferedReader BR = new BufferedReader(FR);
			FileWriter FW = new FileWriter(file, true);
			BufferedWriter BW = new BufferedWriter(FW);
			if (BR.readLine() == null) {
				BW.write(categoriaItem.toString());
			} else {
				BW.newLine();
				BW.write(categoriaItem.toString());
			}
			BR.close();
			BW.close();
			System.out.println("CategoriaItem cadastrado!");
			return categoriaItem;
		} else {
			System.out.println("ERRO: CategoriaItem já cadastrado!");
			return null;
		}
	}

	public ArrayList<CategoriaItem> listar(CategoriaItem categoriaItem) throws IOException {
		ArrayList<CategoriaItem> arrayList = new ArrayList<CategoriaItem>();
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			CategoriaItem Listado = new CategoriaItem();
			Listado.toObject(linha);
			arrayList.add(Listado);
		}
		BR.close();
		return arrayList;
	}

	public boolean editar(CategoriaItem categoriaItem) throws IOException {
		CategoriaItem consultaExist = this.consultar(categoriaItem);
		if (consultaExist != null) {
			ArrayList<CategoriaItem> arrayList = this.listar(null);
			for (int i = 0; i < arrayList.size(); i++) {
				if (arrayList.get(i).getItem().getCodigo() == categoriaItem.getItem().getCodigo()
						&& arrayList.get(i).getCategoria().getCodigo() == categoriaItem.getCategoria().getCodigo()) {
					arrayList.remove(i);
					arrayList.add(categoriaItem);
					File arquivo = DB.load(ClassName);
					arquivo.delete();
				}
			}
			FileWriter FW = new FileWriter(filePath + ClassName + fileType, true);
			BufferedWriter BW = new BufferedWriter(FW);
			for (CategoriaItem h : arrayList) {
				BW.write(h.toString());
				BW.newLine();
			}
			BW.close();
			return true;
		}
		return false;
	}

}
