package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import domain.Item;

public class ItemDAO implements GenericDAO<Item> {
	public String ClassName = "Item";
	public String filePath = "./Files/";
	public String fileType = ".txt";
	public DataBase DB = new DataBase(new File(filePath + ClassName + fileType));

	@Override
	public Item consultar(Item item) throws IOException {
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			String[] dados = linha.split(",");
			if (dados.length > 0 && Integer.parseInt(dados[0]) == item.getCodigo()) {
				Item encontrado = new Item();
				encontrado.toObject(linha);
				BR.close();
				return encontrado;
			}
		}
		BR.close();
		return null;
	};

	@Override
	public Item cadastrar(Item item) throws IOException {
		Item consultaExist = this.consultar(item);
		if (consultaExist == null) {
			File file = DB.load(ClassName);
			FileReader FR = new FileReader(file);
			BufferedReader BR = new BufferedReader(FR);
			FileWriter FW = new FileWriter(file, true);
			BufferedWriter BW = new BufferedWriter(FW);
			if (BR.readLine() == null) {
				BW.write(item.toString());
			} else {
				BW.newLine();
				BW.write(item.toString());
			}
			BR.close();
			BW.close();
			System.out.println("Item cadastrado!");
			return item;
		} else {
			System.out.println("ERRO: Item já cadastrado!");
			return null;
		}
	}

	public ArrayList<Item> listar(Item item) throws IOException {
		ArrayList<Item> arrayList = new ArrayList<Item>();
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			Item Listado = new Item();
			Listado.toObject(linha);
			arrayList.add(Listado);
		}
		BR.close();
		return arrayList;
	}

	public boolean editar(Item item) throws IOException {
		Item consultaExist = this.consultar(item);
		if (consultaExist != null) {
			ArrayList<Item> arrayList = this.listar(null);
			for (int i = 0; i < arrayList.size(); i++) {
				if (arrayList.get(i).getCodigo() == (item.getCodigo())) {
					arrayList.remove(i);
					arrayList.add(item);
					File arquivo = DB.load(ClassName);
					arquivo.delete();
				}
			}
			FileWriter FW = new FileWriter(filePath + ClassName + fileType, true);
			BufferedWriter BW = new BufferedWriter(FW);
			for (Item h : arrayList) {
				BW.write(h.toString());
				BW.newLine();
			}
			BW.close();
			return true;
		}
		return false;
	}

}
