package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;

import domain.Reserva;

public class ReservaDAO implements GenericDAO<Reserva> {
	public String ClassName = "Reserva";
	public String filePath = "./Files/";
	public String fileType = ".txt";
	public DataBase DB = new DataBase(new File(filePath + ClassName + fileType));

	@Override
	public Reserva consultar(Reserva reserva) throws IOException {
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			String[] dados = linha.split(",");
			if (dados.length > 0 && Integer.parseInt(dados[0]) == reserva.getCodigo()) {
				Reserva encontrado = new Reserva();
				encontrado.toObject(linha);
				BR.close();
				return encontrado;
			}
		}
		BR.close();
		return null;
	};

	@Override
	public Reserva cadastrar(Reserva reserva) throws IOException {
		Reserva consultaExist = this.consultar(reserva);
		if (consultaExist == null) {
			File file = DB.load(ClassName);
			FileReader FR = new FileReader(file);
			BufferedReader BR = new BufferedReader(FR);
			FileWriter FW = new FileWriter(file, true);
			BufferedWriter BW = new BufferedWriter(FW);
			if (BR.readLine() == null) {
				BW.write(reserva.toString());
			} else {
				BW.newLine();
				BW.write(reserva.toString());
			}
			BR.close();
			BW.close();
			System.out.println("Reserva cadastrado!");
			return reserva;
		} else {
			System.out.println("ERRO: Reserva já cadastrado!");
			return null;
		}
	}

	public ArrayList<Reserva> listar(Reserva reserva) throws IOException {
		ArrayList<Reserva> arrayList = new ArrayList<Reserva>();
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			Reserva Listado = new Reserva();
			Listado.toObject(linha);
			arrayList.add(Listado);
		}
		BR.close();
		return arrayList;
	}

	public boolean editar(Reserva reserva) throws IOException {
		Reserva consultaExist = this.consultar(reserva);
		if (consultaExist != null) {
			ArrayList<Reserva> arrayList = this.listar(null);
			for (int i = 0; i < arrayList.size(); i++) {
				if (arrayList.get(i).getCodigo() == (reserva.getCodigo())) {
					arrayList.remove(i);
					arrayList.add(reserva);
					File arquivo = DB.load(ClassName);
					arquivo.delete();
				}
			}
			FileWriter FW = new FileWriter(filePath + ClassName + fileType, true);
			BufferedWriter BW = new BufferedWriter(FW);
			for (Reserva h : arrayList) {
				BW.write(h.toString());
				BW.newLine();
			}
			BW.close();
			return true;
		}
		return false;
	}

	public void pagarReserva(int v) {
		Reserva consultaExist = new Reserva();
		consultaExist.setCodigo(v);
		try {
			consultaExist = this.consultar(consultaExist);
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (consultaExist != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			try {
				consultaExist.setDataCheckout(formatter.parse(LocalDateTime.now().toString()));
				consultaExist.setValorPago(consultaExist.getValorReserva());
				consultaExist.setFuncionarioFechamento(consultaExist.getFuncionarioReserva());
				this.editar(consultaExist);
				System.out.println("Pago com sucesso!");
			} catch (ParseException e) {
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
