package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import domain.Consumo;

public class ConsumoDAO implements GenericDAO<Consumo> {
	public String ClassName = "Consumo";
	public String filePath = "./Files/";
	public String fileType = ".txt";
	public DataBase DB = new DataBase(new File(filePath + ClassName + fileType));

	@Override
	public Consumo consultar(Consumo consumo) throws IOException {
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			String[] dados = linha.split(",");
			if (dados.length > 0 && Integer.parseInt(dados[0]) == consumo.getItem().getCodigo()
					&& Integer.parseInt(dados[1]) == consumo.getReserva().getCodigo()) {
				Consumo encontrado = new Consumo();
				encontrado.toObject(linha);
				BR.close();
				return encontrado;
			}
		}
		BR.close();
		return null;
	};

	@Override
	public Consumo cadastrar(Consumo consumo) throws IOException {
		Consumo consultaExist = this.consultar(consumo);
		if (consultaExist == null) {
			File file = DB.load(ClassName);
			FileReader FR = new FileReader(file);
			BufferedReader BR = new BufferedReader(FR);
			FileWriter FW = new FileWriter(file, true);
			BufferedWriter BW = new BufferedWriter(FW);
			if (BR.readLine() == null) {
				BW.write(consumo.toString());
			} else {
				BW.newLine();
				BW.write(consumo.toString());
			}
			BR.close();
			BW.close();
			System.out.println("Consumo cadastrado!");
			return consumo;
		} else {
			System.out.println("ERRO: Consumo já cadastrado!");
			return null;
		}
	}

	public ArrayList<Consumo> listar(Consumo consumo) throws IOException {
		ArrayList<Consumo> arrayList = new ArrayList<Consumo>();
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			Consumo Listado = new Consumo();
			Listado.toObject(linha);
			arrayList.add(Listado);
		}
		BR.close();
		return arrayList;
	}

	public boolean editar(Consumo consumo) throws IOException {
		Consumo consultaExist = this.consultar(consumo);
		if (consultaExist != null) {
			ArrayList<Consumo> arrayList = this.listar(null);
			for (int i = 0; i < arrayList.size(); i++) {
				if (arrayList.get(i).getItem().getCodigo() == consumo.getItem().getCodigo()
						&& arrayList.get(i).getReserva().getCodigo() == consumo.getReserva().getCodigo()) {
					arrayList.remove(i);
					arrayList.add(consumo);
					File arquivo = DB.load(ClassName);
					arquivo.delete();
				}
			}
			FileWriter FW = new FileWriter(filePath + ClassName + fileType, true);
			BufferedWriter BW = new BufferedWriter(FW);
			for (Consumo h : arrayList) {
				BW.write(h.toString());
				BW.newLine();
			}
			BW.close();
			return true;
		}
		return false;
	}

}
