package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import domain.Categoria;

public class CategoriaDAO implements GenericDAO<Categoria> {
	public String ClassName = "Categoria";
	public String filePath = "./Files/";
	public String fileType = ".txt";
	public DataBase DB = new DataBase(new File(filePath + ClassName + fileType));

	@Override
	public Categoria consultar(Categoria categoria) throws IOException {
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			String[] dados = linha.split(",");
			if (dados.length > 0 && Integer.parseInt(dados[0]) == categoria.getCodigo()) {
				Categoria encontrado = new Categoria();
				encontrado.toObject(linha);
				BR.close();
				return encontrado;
			}
		}
		BR.close();
		return null;
	};

	@Override
	public Categoria cadastrar(Categoria categoria) throws IOException {
		Categoria consultaExist = this.consultar(categoria);
		if (consultaExist == null) {
			File file = DB.load(ClassName);
			FileReader FR = new FileReader(file);
			BufferedReader BR = new BufferedReader(FR);
			FileWriter FW = new FileWriter(file, true);
			BufferedWriter BW = new BufferedWriter(FW);
			if (BR.readLine() == null) {
				BW.write(categoria.toString());
			} else {
				BW.newLine();
				BW.write(categoria.toString());
			}
			BR.close();
			BW.close();
			System.out.println("Categoria cadastrado!");
			return categoria;
		} else {
			System.out.println("ERRO: Categoria já cadastrado!");
			return null;
		}
	}

	public ArrayList<Categoria> listar(Categoria categoria) throws IOException {
		ArrayList<Categoria> arrayList = new ArrayList<Categoria>();
		String linha;
		FileReader FR = new FileReader(DB.load(ClassName));
		BufferedReader BR = new BufferedReader(FR);
		while ((linha = BR.readLine()) != null) {
			Categoria Listado = new Categoria();
			Listado.toObject(linha);
			arrayList.add(Listado);
		}
		BR.close();
		return arrayList;
	}

	public boolean editar(Categoria categoria) throws IOException {
		Categoria consultaExist = this.consultar(categoria);
		if (consultaExist != null) {
			ArrayList<Categoria> arrayList = this.listar(null);
			for (int i = 0; i < arrayList.size(); i++) {
				if (arrayList.get(i).getCodigo() == (categoria.getCodigo())) {
					arrayList.remove(i);
					arrayList.add(categoria);
					File arquivo = DB.load(ClassName);
					arquivo.delete();
				}
			}
			FileWriter FW = new FileWriter(filePath + ClassName + fileType, true);
			BufferedWriter BW = new BufferedWriter(FW);
			for (Categoria h : arrayList) {
				BW.write(h.toString());
				BW.newLine();
			}
			BW.close();
			return true;
		}
		return false;
	}

}
